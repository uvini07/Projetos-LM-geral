import java.util.Scanner;

public class Fahrenheit {
	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("BEM VINDO AO NOSSO CONVERSOR DE TEMPERATURA");
		
		double C, F;
		
		System.out.println("INFORME GRAUS EM FAHRENHEIT: ");
		F = scanner.nextDouble();
		
		C = (F-32)/1.8;
		
		System.out.println("Fahrenheit = " + C);
	
		}
	}
